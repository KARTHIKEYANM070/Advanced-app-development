package com.job_portal.online_job_portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineJobPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
