export default[
    {
        id:1,
        postedOn:'2024-01-28',
        title:'FrontEnd Developer',
        company:'Apple',
        type:'Full Time',
        experience:'Mid Level',
        location:'Remote',
        skills:["React","Java","Spring"],
        Job_Link:"https://www.apple.com/careers/in/"
    },
    {
        id:2,
        postedOn:'2024-01-14',
        title:'backEnd Developer',
        company:'Google',
        type:'Full Time',
        experience:'Mid Level',
        location:'Remote',
        skills:["Cloud","Java","Spring"],
        Job_Link:"https://www.apple.com/careers/in/"
    },
    {
        id:3,
        postedOn:'2024-01-14',
        title:'backEnd Developer',
        company:'Google',
        type:'Full Time',
        experience:'Mid Level',
        location:'Remote',
        skills:["Cloud","Java","Spring"],
        Job_Link:"https://www.apple.com/careers/in/"
    }
]