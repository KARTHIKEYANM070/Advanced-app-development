import React from 'react'

export const Navbariop = () => {
  return (
    <div className='h-20 flex items-center w-full text-white'>
        <div className='text-3xl pl-20 font-bold'>Joboard</div>
    </div>

  )
}
