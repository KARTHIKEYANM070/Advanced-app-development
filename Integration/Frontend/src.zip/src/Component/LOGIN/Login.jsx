import React from 'react'
import About from './About'
const Lsig = () => {
  return (
    <div>
      <About/>
    </div>
  )
}

export default Lsig