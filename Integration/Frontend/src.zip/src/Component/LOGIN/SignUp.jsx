import React from 'react'
import Signu from './Signu'
const SignUp = () => {
  return (
    <div>
      <Signu/>
    </div>
  )
}

export default SignUp