import React from 'react'
import Admin from '../Admin/Admin';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import Adminlogin from '../Admin/Adminlogin';
export const Contact = () => {
  return (
   <div>
    <Adminlogin/> 
   </div>
  )
}
